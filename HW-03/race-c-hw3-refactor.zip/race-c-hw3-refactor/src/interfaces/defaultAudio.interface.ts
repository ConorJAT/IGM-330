export default interface DefaultAudio{ 
    audio : string 
}