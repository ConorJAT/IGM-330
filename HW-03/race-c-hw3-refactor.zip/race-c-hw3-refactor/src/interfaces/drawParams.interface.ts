export default interface DrawParams{
	visualData    : string,
	showGradient  : boolean,
	showPlanets   : boolean,
	showCircles   : boolean,
	showNoise     : boolean
};