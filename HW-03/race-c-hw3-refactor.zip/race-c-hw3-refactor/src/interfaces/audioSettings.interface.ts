export default interface AudioSettings{
    gain : number,
    numSamples : number
}