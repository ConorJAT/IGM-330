import * as main from "./main.js";

main.init();