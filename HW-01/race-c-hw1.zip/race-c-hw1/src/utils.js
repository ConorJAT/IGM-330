// Return a random int based on an array length parameter.
export const getRandom = array => array[Math.floor(Math.random() * array.length)];